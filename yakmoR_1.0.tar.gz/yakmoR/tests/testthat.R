library(testthat)
library(yakmoR)

test_check("yakmoR")
